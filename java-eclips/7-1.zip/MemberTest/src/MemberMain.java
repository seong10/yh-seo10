
public class MemberMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Member m1 = new Member();
//		
//		m1.print();
		
//		m1.name = "Mike";
//		m1.tel = "010-1234-5678";
//		m1.address = "Seoul 101";
//		m1.setMember("Mike", "010-1234-5678", "Seoul 101");
		
		Member m1 = new Member("Mike", "010-1234-5678", "Seoul 101");
		
		m1.print();
		
		// 이건 안됨 왜? 함수세개랑 꼭 같이 동작해야되는 함수
		// 그렇지만 메소드오버로딩만들면? 가능하다
		Member m2 = new Member();
				
		m2.setMember("Hong", "333-3333", "Incheon");
		
		m2.print();
		
	}

}
