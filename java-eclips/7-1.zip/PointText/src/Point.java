
// GPS(점) 좌표정보를 가지고 있는 클래스
public class Point {
	// 클래스의 멤버변수
	int x;
	int y;
	
//	void print() {
//		System.out.println( "x : " + x + ", y : " + y);
//	}
	
	int print() {
		// 로컬 변수 (local vavriables)
		int i = 0;
		System.out.println( "x : " + x + ", y : " + y);
		return i;
	
	
	}
}
