// public 안써도
public class Hello{
		// 클래스name
		// java 는 들여쓰기를 {}(중괄호) 로함
	public static void main(String[] args) {
		System.out.println("안녕하세요");
	} // system 의 라이브러리의 out 의 println 으로 하는것
}						// 문자열 > ""(큰따옴표로), 그리고 ; 세미콜론
