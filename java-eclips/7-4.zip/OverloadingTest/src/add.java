
// 두 데이터를 더하는 클래스
public class add {

	// 함수의 파라미터나, 리턴데이터타입이 다르면,
	// 함수의 이름을 똑같이 할 수 있다.
	// 이런방법을 메소드 오버로딩 이라고 한다
	int add(int x, int y) {
		return x+y;
	}
	
	float add(float x, float y) {
		return x+y;
	}
	
	double add(double x, double y) {
		return x+y;
	}
	
	String add(String x, String y) {
		return x+y;
	}
	
}
