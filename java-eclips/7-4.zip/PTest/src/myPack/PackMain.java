package myPack;

import myPack.text.Member;

public class PackMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Hello");
		
		// 친구 전번을 저장하기 위한 Member 객체를 생성한다.
			// Member 라는게 여러가지가 있을 수 있다 구분짓기 위해서
			// > import
		Member m1 = new Member();
		// 친구 Mike, 010-12345 를 저장하세요.
		
		// 1. 다이렉트로 저장하는 방법
		m1.name = "Mike";
		m1.phone = "010-2222-3333";
				// 안되는이유? 같은폴더가 아니기에
		
		// 2. Member 가 제공하는 함수로 저장하는 방법
		m1.setMember("Mike", "010-12345");
		
		// 객체를 생성한 후에, 데이터를 셋팅하려면
		// 따로 무엇인가를 해줘야 한다. "접근 제어자" > private, public 이런것들
		
		
		// "Mike", "010-12345" 를 아예
		// m2 라는 변수(객체 생성할때)만들때 저장하도록 하자.
		
		// 3. 생성자로 만드는 방법
		Member m2 = new Member("Mike", "010-12345");
		
		// 멤버변수 각각의 데이터에 값을 저장하고 가져오는 방법
		
		// 주소록에, 이름만 수정하려 할때.
		// m1 의 이름을 Harry 로 바꾸려고 한다.
		
		// 1. 직접 멤버변수를 변경하는 경우.
		m1.name = "Harry";
		
		// 2. 함수를 이용해서 변경하는 경우.
		m1.setName("Harry");
		
		System.out.println(m1.name);
		// m2 에 저장된 이름을 가져오세요.
		System.out.println(m2.name);
		
		// m2 에 저장된 이름을 가져오되, 함수로 가져오세요.
		String name = m2.getName();
		System.out.println(name);
		
		// Getter / Setter
		// 클래스의 멤버변수 한개의 값을 저장할때 사용하는 함수
		// 클래스의 멤버변수 한개의 값을 가져올때 사용하는 함수
		
		
		// phone 데이터를 가져오고, 셋팅하는
		// 게터 세터 함수를 만들어 주세요.
		String phone = m1.getPhone();
		System.out.println(phone);
		m1.setPhone("010-123");
		System.out.println(m1.phone);
		
	}

}
