package myPack.text;

public class Member {

	// heap 메모리에 저장되는것
	// heap 메모리는 없어지지 않는것
	public String name;
	public String phone;
		// defult 값은 같은 폴더안에 있을때, 그럼 다른폴더에 있을때는? public
		// public(공개하다) > 다른 클래스, 폴더에서 억세스 하게 해주려면
	
	public void setMember(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}
	
	public Member(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}
	
	public Member() {
		
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}

