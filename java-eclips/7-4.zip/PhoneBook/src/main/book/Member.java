package main.book;

public class Member {

	// 이름과 전화번호를 저장합니다.
		// 이 클래스에서만 쓰는 변수니까 public 필요없음
	private String name;
	private String phone;
		//private 했지만 같은 클래스 안에서는 자기껏이니까 사용가능
	//
	public Member(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}

	public void print() {
		System.out.println("Name : " + name + " , Phone : " + phone);
	}
	
	// 툴로 가능하다
	// 마우스오른쪽 > source > getters setters
	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getName() {
		return name;
	}
	//////////
	
	// 오류를 클릭하면 자동생성 가능
	public Member() {
		// TODO Auto-generated constructor stub
	}

	
}
