
public class StaticMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		StaticVar v1 = new StaticVar();
		
		v1.staticTest();
		
		StaticVar v2 = new StaticVar();
		
		// 함수를 새로 만들었으니 새로 불러와야 하는데 +1 이 왜?
		// static 메모리가 따로 있으니 v1 v2 함수가 상관없이
		// 저장되어 있는것
		v2.staticTest();
		// 3
		// 2
		v2.staticTest();
	}	// 4
		// 3

}
