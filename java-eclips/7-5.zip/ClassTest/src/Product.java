
public class Product {

	
	int num;
	String name;
	
}