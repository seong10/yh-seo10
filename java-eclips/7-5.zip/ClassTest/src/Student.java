
public class Student {
		
	String name;
	int kor;
	int eng;
	int math;
	int sum;
	double avg;
	
	// 함수를 만들어 준다.
	// sum 변수와, avg 변수를 한번에 계산해서
	// 저장해 주는 함수.
	
	// 클래스의 함수에서, 클래스의 멤버변수는 마음대로
	// 가져다 쓸수 있다
	void calculate() {
// 출력은 리턴이 없다 > void
		sum = kor + eng + math;
		avg = (double) sum / 3;
	}
	
	void print() {
		System.out.println(name);
		System.out.println(kor);
		System.out.println(eng);
		System.out.println(math);
		System.out.println(sum);
		System.out.println(avg);
		System.out.println("--------");
	}
	
}