
public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Student s1 = new Student();
		Student s2 = new Student();
//		
//		s1.name = "김태희";
//		s1.kor = 90;
//		s1.eng = 95;
//		s1.math = 100;
//		s1.sum = s1.kor + s1.eng + s1.math;
//		s1.avg = s1.sum / 3;
//		
//		s2.name = "원빈";
//		s2.kor = 80;
//		s2.eng = 90;
//		s2.math = 70;
//		s2.sum = s2.kor + s2.eng + s2.math;
//		s2.avg = s2.sum / 3;
//	
//		System.out.println(s1.name);
//		System.out.println(s1.kor);
//		System.out.println(s1.eng);
//		System.out.println(s1.math);
//		System.out.println(s1.sum);
//		System.out.println(s1.avg);
//		
//		System.out.println(s2.name);
//		System.out.println(s2.kor);
//		System.out.println(s2.eng);
//		System.out.println(s2.math);
//		System.out.println(s2.sum);
//		System.out.println(s2.avg);
//		
//		// 영어점수가 88점으로 바꼈다
//		s2.eng = 88;
//		System.out.println(s2.eng);
//		// 그런데? sum, avg도 바꿔야된다 / 문제가있다
//		// 위의 영어 점수만 바뀌는것이지,
//		// 총합과 평균은, 메모리에 저장되있는것이 바뀌지 않다
//		s2.sum = s2.kor + s2.eng + s2.math;
//		s2.avg = s2.sum / 3;
//		
//		System.out.println(s2.name);
//		System.out.println(s2.kor);
//		System.out.println(s2.eng);
//		System.out.println(s2.math);
//		System.out.println(s2.sum);
//		// 79. ... 나와야 될텐데? 79.0으로 나옴
//		// 왜? int로 함수를 만들었기에
//		// 그래서 데이터 타입 변화
//		s2.avg = (double) s2.sum / 3;
//		System.out.println(s2.avg);
		
		s1.name = "김태희";
		s1.kor = 90;
		s1.eng = 95;
		s1.math = 100;
		s1.calculate();
		
//		System.out.println(s1.name);
//		System.out.println(s1.kor);
//		System.out.println(s1.eng);
//		System.out.println(s1.math);
//		System.out.println(s1.sum);
//		System.out.println(s1.avg);
//		
		// s1의 영어점수를 79점으로 바꾸겠습니다
		s1.eng = 79;
		s1.calculate();
		
		s1.print();
//		
//		System.out.println(s1.name);
//		System.out.println(s1.kor);
//		System.out.println(s1.eng);
//		System.out.println(s1.math);
//		System.out.println(s1.sum);
//		System.out.println(s1.avg);
		
		// 멤버변수의 값을 출력하는,
		// 클래스의 멤버 메소드를 만들어 주세요
		s1.print();
		
	}

}
