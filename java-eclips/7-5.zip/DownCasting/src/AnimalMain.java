
public class AnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Animal a = new Animal();
//		a.setName("동물");
//		a.cry();
//		
//		System.out.println("-------------");
//		
//		Dog d = new Dog();
//		d.setName("바둑이");
//		d.cry();
//		d.run();
//		
//		System.out.println("-------------");
//		
//		Cat c = new Cat();
//		c.setName("키티");
//		c.cry();
//		c.grooming();
		
		AnimalAction action = new AnimalAction();
		
		Dog d = new Dog();
		d.setName("바둑이");
		
		action.action(d);
		
		Cat c = new Cat();
		c.setName("키티");
		
		action.action(c);
		
	}

}
