
public class Dog extends Animal {

//	String name;
	
	// Animal 클래스의 함수도 모두 상속받는다.
	
	@Override
	public void cry() {
		// TODO Auto-generated method stub
		super.cry();
		System.out.println("멍멍멍~~");
	}

	public void run() {
		System.out.println( getName() + "가 뛴다!!" );
	}
	
}
