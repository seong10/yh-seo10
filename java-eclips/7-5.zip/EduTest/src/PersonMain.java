import main.person.Person;
import main.person.Professor;
import main.person.Staff;
import main.person.Student;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person p = new Person();
//		p.name = "홍길동";
		// private 이라면 set,get 함수로 불러와야됨 직접적으로 불가능
		p.setNum(1);
		p.setName("홍길동");
		p.setDept("홍보부");
		p.setAddress("인천시 서구");
		
		p.print();
		
		System.out.println("------------------");
		
		Professor f = new Professor();
		f.setNum(2);
		f.setName("김나나");
		f.setDept("컴공과");
		f.setAddress("서울시 마포구");
		f.setSubjects( new String[] {"자바", "파이썬"} );
		
		f.print();
		
		System.out.println("------------------");
		
		Student s = new Student();
		s.setNum(3);
		s.setName("김철수");
		s.setDept("경영학과");
		s.setAddress("경기도 성남시");
		s.setSubjects( new String[] {"자바", "마케팅", "사회"} );
		
		s.print();
		
		System.out.println("------------------");
		
		Staff sf = new Staff();
		sf.setNum(4);
		sf.setName("이영희");
		sf.setDept("인사팀");
		sf.setAddress("강원도");
		sf.setJob("교육부");
		
		sf.print();
		
		System.out.println("------------------");
		System.out.println("------------------");
		
		Person p2 = new Person(5, "김말숙", "청소부", "시흥시");
//		p2.setPerson(5, "김말숙", "청소부", "시흥시");
// 객체생성을 할때 바로 대입하려면은 비어있는 객체인, Person을 만들어 줘야하고
// setPerson을 할 필요가 없음
		p2.print();
//			 서비스차원 개념에서 printsubject 라던지로 한다면 복잡하다
//			 가져다쓰기 편하게 print 로 통일하고 싶다
//			 이것이 메소드 오버라이딩 개념
		
		System.out.println("------------------");
		
		Professor f2 = new Professor(6, "강호동", "체육부", "부평시",
				new String[] {"자바", "파이썬", "강습"});
		f2.print();
		
		System.out.println("------------------");
		
		Staff s2 = new Staff(7, "강미선", "홍보부", "강서구", "마케팅");
		s2.print();
		
		System.out.println("------------------");
		
		Student st2 = new Student(8, "강말숙", "홍보부2", "강서구2", 
				new String[] {"자바", "강습"});
		st2.print();
		
		
	}

}
