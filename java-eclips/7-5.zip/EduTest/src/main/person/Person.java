package main.person;

public class Person {

	protected int num;
	protected String name;
	// String name; > 아무것도 안쓰면? 디폴트
	// protected String name; > 상속받은 애들은 사용 가능하게,
	// 하지만 다른 폴더에 있으면 안됨
	protected String dept;
	protected String address;
	
	public void print() {
		System.out.println("num : " + num);
		System.out.println("name : " + name);
		System.out.println("dept : " + dept);
		System.out.println("address : " + address);
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	// 객체생성을 할때 바로 대입하려면은 비어있는 객체인, Person을 만들어 줘야하고
	// setPerson을 할 필요가 없음
	public Person() {
		
	}
	
	public Person(int num, String name, String dept,
			String address) {
		this.num = num;
		this.name = name;
		this.dept = dept;
		this.address = address;
	}
	
}
