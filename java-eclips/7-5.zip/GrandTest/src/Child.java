
public class Child extends Parent {

//	String name;
//	int age;
	
	// GrandParent 의 함수들도 상속받았다.
	
//	String job;
	
	// parent 의 함수들도 상속 받았다.
	
	String hobby;
	
	public Child() {
		System.out.println("Child 생성자 호출됨");
	}
	
	public Child(String name, int age, String job, String hobby) {
		super(name, age, job);
		this.hobby = hobby;
	}

	@Override
	void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println(hobby);
	}
	
	
	
	
}
