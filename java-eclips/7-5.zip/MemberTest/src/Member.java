
// 주소록 서비스를 위한 멤버 데이터 저장하는 클래스
public class Member {

	// 멤버변수
	String name;
	String tel;
	String address;
	
	// 생성자 : 함수의 리턴타입이 없고! 클래스의 이름과 같은함수
	// 메모리에 영역을 확보하고, 바로 멤버변수에 데이터를 셋팅!
	Member(String name, String tel, String address) { 
		this.name = name;
		this.tel = tel;
		this.address = address;
	} // this : 멤버변수를 this 에다 저장해라
	// 멤버변수 name 에다 저장해라 메모리? heap
	
	// 메소드오버로딩
	// 함수가 똑같애도 동작하게 만든것
	Member(){
		
	}
	
	Member(String name){
		this.name = name;
	}
	
	void setMember(String name, String tel, String address) {
		this.name = name;
		this.tel = tel;
		this.address = address;
	// this를 쓰니
	}
	
	void setMember(String tel, String address) {
		this.tel = tel;
		this.address = address;
	}
		
	void print() {
		System.out.println("name : "+ name
				+ " , tel : " + tel);
		System.out.println("Address : " + address);
	}
	
}
