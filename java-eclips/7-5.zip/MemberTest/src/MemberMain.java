
public class MemberMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Member m1 = new Member();
//		
//		m1.print();
		
//		m1.name = "Mike";
//		m1.tel = "010-1234-5678";
//		m1.address = "Seoul 101";
//		m1.setMember("Mike", "010-1234-5678", "Seoul 101");
		
		Member m1 = new Member("Mike", "010-1234-5678", "Seoul 101");
					// 메모리에 변수를 만드려면 new
					// 클래스는 모두 대문자로 시작 Member
		// 메모리가 왼쪽이 stack 오른쪽이 new이기에 heap
		// 생성자 : 메모리에 생성해주기 때문에 생성자
		// new Member : 클래스랑 똑같이생긴 함수 > 이게 생성자
		m1.print();
			// heap 메모리는 지워지지 않는다
			// stack 의 m1 이 heap 의 m1 데이터를 가르킴
		
			// heap 에 class가 올라 온것을 객체라고 한다
		
		// 이건 안됨 왜? 함수세개랑 꼭 같이 동작해야되는 함수
		// 그렇지만 메소드오버로딩만들면? 가능하다
		Member m2 = new Member();
				
		m2.setMember("Hong", "333-3333", "Incheon");
		
		m2.print();
		
		// 친구의 이름만 먼저 저장하고,
		// 전번과 주소는 나중에 저장하려 한다.
		Member m3 = new Member("아이유");
		
		m3.print();
		
		// 전화번호와 주소를 저장하려 한다.
		// 전화번호와 주소를 저장하는 함수를 만들어 주세요.
		m3.setMember("010-555", "Incheon, Seogu");
		
		m3.print();
		
		// 같은 폴더라서 Member 접근 바로됨
		Member m4 = new Member();
		m4.name = "Mike";
		
	}

}
