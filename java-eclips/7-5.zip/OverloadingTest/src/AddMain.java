
public class AddMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 클래스를 가지고 변수를 만드는것을
		// 유식한말로 객체 생성 이라고 한다.
		add a = new add();
//		
//		int result = a.add(3, 5);
//		
//		System.out.println(result);
//		
//		// 2개의 float 을 더하는 함수를 만들고 싶다.
//		
//		float result2 = a.addFloat(3.5f, 1.8f);
//		
//		System.out.println(result2);
//		
//		// 2개의 double 을 더하는 함수를 만들고 싶다.
//		
//		double result3 = a.addDouble(3.8, 2.9);
//		System.out.println(result3);
//		
//		// 2개의 문자열 을 더하는 함수를 만들고 싶다.
//		String result4 = a.addString("Hello", "Bye");
//		System.out.println(result4);
//		
		double result5 = a.add(3.8, 2.9);
		System.out.println(result5);
		
	}

}
