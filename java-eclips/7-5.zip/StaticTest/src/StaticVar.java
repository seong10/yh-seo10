
public class StaticVar {

	static int a = 1; // static 이라는 메모리가 생긴것
//	int a = 1; // 하면 단순한 논리로의 결과값
	int b = 1;
	
	void staticTest() {
		a = a + 1;
		b = b + 1;
		System.out.println("static int a : "+a);
		System.out.println("member int b : "+b);
	}
	
}
