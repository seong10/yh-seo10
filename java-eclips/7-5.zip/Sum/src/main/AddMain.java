package main;

import main.calculate.Data;
import main.calculate.Data2;

public class AddMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Data2 클래스를 객체 생성하면서!
		// 두 정수 3과 5를 넘겨주면, 두 정수의 합을 저장하도록
		// 하는 코드를 작성하세요.
		Data2 data2 = new Data2(3,5);

		data2.printInt();
		
		// 두 더블형 실수를 넘겨주면, 두 실수의 합을 저장
		Data2 data3 = new Data2(3.3, 5.5);
		
		data3.printDouble();
		
		// 두 문자열을 넘겨주면, 두 문자열을 붙여서 저장
		Data2 data4 = new Data2("Hi", "llo");
		
		data4.printString();
		
		
		// 두 정수를 더해서 화면에 출력!
		Data data = new Data();
			// 1. 클래스를 먼저 객체로 만듬 2. Data 클래스 import 
		int result = data.add(1, 2);
		System.out.println(result);
		
//		Data data2 = new Data();
			// 필요없음
		double result2 = data.add(1.1, 2.2);
		System.out.println(result2);
		
//		Data data3 = new Data();
		String result3 = data.add("h", "i");
		System.out.println(result3);
		
	}

}
