
public class UpCastingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// UpCasting 클래스의 객체를 생성할때,
		// 자동으로 x는 10, y 는 20이 저장되도록 하시오.
		// 단, 생성자의 파라미터는 아것도 안씁니다
		
		UpCastingParent up = new UpCastingParent();
		System.out.println(up.x);
		
		up.print();
		
		int result = up.add();
		
		System.out.println(result);
		
		// UpCastingChild 클래스의 객체 생성시
		// 생성자의 파라미터는 아무것도 없이,
		// x 는 100, y 는 200, z 는 300으로 초기화하는 코드를 작성하세요.
		
		UpCastingChild uc = new UpCastingChild();
		
		result = uc.add();
		
		System.out.println(result);
		
		result = uc.add();
		System.out.println(result);
		
		
		System.out.println("-----------------");
		
		UpCastingParent ucp = new UpCastingChild();
			// new UpCastingChild 함수로가 상속받은 Parent로가고
			// x = 10 , y = 10 heap에 저장하고
			// 다시 child로와 xyz 다시 저장하고
			// stack 에서는 parent 로 생성된 ucp가 heap에 가르킴
			// 즉 변수를 parent (부모클래스) (ucp)
			// 부모클래스가 자식클래스를(heap) 을 가리키는것을 '업클래스'라고함
			// 부모의 add 함수를 호출하려니 오버라이딩된 자식 클래스를 호출하고
			// sub 함수를 호출하려니 부모한테 sub 없음 / 오버라이딩 할 수가 없음
			// new 
		
		
		// 변수는 부모클래스이므로, 부모클래스에 add 함수 이름이 있으므로,
		// 함수가 실행되되, 객체(heap 메모리)가 자식 클래스이고,
		// 자식 클래스가 add 를 오버라이딩 했으므로,
		// 자식클래스의 함수가 호출된다.
		result = ucp.add();
		
		System.out.println(result);
		
		// 변수는 부모클래스이므로, 부모클래스에 있는 함수 이름만 사용이 가능!
		// sub() 는 부모에는 없고, 자식에게만 있으니까 실행 못한다
//		result = ucp.sub();
		
	}

}
