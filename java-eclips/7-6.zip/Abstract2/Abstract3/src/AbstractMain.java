
public class AbstractMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Child c = new Child();
		
		c.name = "홍길동";
		c.age = 30;
		c.hobby = "Movie";
		
		c.print();
		c.test();
		
	}

}
