
public class Child extends Parent {
	
//	String name;
//	int age;
	
	String hobby;
	
	@Override
	public void test() {
		// TODO Auto-generated method stub
		System.out.println("Hobby = " + hobby);
	}
	
	

}
