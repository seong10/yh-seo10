
public abstract class GrandParent {
	// abstract 클래스는
	// 마음대로 클래스 멤버변수와 메소드를 만들지 말고
	// abstract 클래스안에서 정해준대로 상속받아서 써야한다는 뜻
	
	
	
	String name;
	int age;
	
	// 최상위클래스에서는 하위클래스에서 개발 진행할 수 있도록 함수를 만드는데
	// 함수를 이름만 만들어 놓는다. (내용은 없다.)
	
	public abstract void print();
	
	public abstract void test();
	
}
