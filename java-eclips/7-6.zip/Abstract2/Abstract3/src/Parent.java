
public abstract class Parent extends GrandParent {

	// 추상클래스를 상속받아서 개발하는 클래스는
	// 추상 클래스의 모든 추상함수를 다 구현해 줘야 한다.
	
//	String name;
//	int age;
	
	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Parent");
		System.out.println("name = " + name);
	}

	
	

	
	

}
