
public class Child extends Parent{

	public String hobby;
	
	@Override
	public void test() {
		System.out.println(hobby);
	}
	
}
