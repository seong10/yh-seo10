
public class Child extends Parent{

	public String hobby;
	
	Child(){
		
	}
	
	@Override
	public void test() {
		System.out.println(hobby);
	}
	
}
