
public abstract class GreandParent {
	// abstract 클래스는
	// 마음대로 클래스 멤버변수와 메소드를 만들지 말고
	// abstract 클래스안에서 정해준대로 상속받아서 써야한다는 뜻

	String name;
	int age;
	
	// 최상위클래스에서는 하위클래스에서 개발 진행할 수 있도록 함수를 만드는데
	// 함수를 이름만 만들어 놓는다. (내용은 없다.)
	
	// 팀장이 밑에 클래스 나눠주는것
	// 내가만든 클래스를 만들어서 클래스를 나눠준다
	abstract public void print();
	
	
	abstract public void test();
	
}
