
public abstract class Parent extends GreandParent {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("name");
		
	}
	// 중간관리자가 하려면?
	
	// 추상클래스를 상속받아서 개발하는 클래스는
	// 추상클래스의 모든 추상함수를 다 구현해 줘야 힌다!
	
	// /ovevrride 해야됨
	
	
	
}
