import java.util.ArrayList;

public class AddressMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Member> memberList = new ArrayList<Member>();
		
		Member m1 = new Member("홍길동", "010-2323-4123");
//		m1.name = "홍길동";
//		m1.phone = "010-2323-4123" 가 불편하므로

		memberList.add(m1);
		
		m1 = new Member("김나나", "010-4567-1212");
		
		memberList.add(m1);
		
		m1 = new Member("Mike", "010-6433-5945");
		
		memberList.add(m1);
		
		for(int i = 0; i < memberList.size(); i++) {
			System.out.println( memberList.get(i).getName() );
		 // Member을 넣었으니 객체가 찍힌것		// 그래서 .name / private 하면? > get
			System.out.println( memberList.get(i).getPhone() );
		}
		
		System.out.println("-----------------");
		
		String keyword = "45";
		// keyword 가 포함된 전화번호만
		// 그사람의 이름과 폰번을 화면에 출력하세요.
		for(int i = 0; i < memberList.size(); i++) {
			
			Member member = memberList.get(i);
		// member 을 안만들고 아래처럼 작성가능, 하지만 가독성은 member로 정리하는게 더 좋음	
		// if(memberList.get(i).getPhone().contains(keyword))
			if (member.getPhone().contains(keyword)) {
			System.out.println( memberList.get(i).getName() );
			System.out.println( memberList.get(i).getPhone() );
			}
		}
		
		
	}
}
