
public class Member {

	private String name;
	private String phone;
	
	public Member(String name, String phone){
		this.name = name;
		this.phone = phone;
	}
	
	void print() {
		System.out.println("이름은 : " + name + " , 폰번은 : " + phone);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	
}
