
public class ProductMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 클래스를 메모리에 올려야, 사용할 수 있다.
		// 클래스 > 변수와 함수의 집함 / 클래스는 틀 일 뿐이다
		// 이렇게 메모리에 올라온 상테를 객체(Instance, Object)라고 한다!!
		// 객체 > 클래스를 변수(메모리)로 만들어준것
		Product p1 = new Product();
		p1.num = 1;
		p1.name = "computer";
		
		Product p2 = new Product();
		p2.num = 2;
		p2.name = "oven";
		
		// p1 의 제품번호와 제품명 출력해주세요
		System.out.println(p1.num);
		System.out.println(p1.name);
		
		System.out.println(p2.num);
		System.out.println(p2.name);
		
		
	}

}
