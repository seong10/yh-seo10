import java.util.ArrayList;

public class ArrayListTest {

	public static void main(String[] args) {
		
		// 배열은, 생성시에, 갯수를 정해줘야 한다!
		// 배열은 한번 갯수를 정하면, 그 갯수 이상으로는 데이터를 추가 불가!
		String[] nameArray = new String[10];
		// ArrayList > java.util 패키지에 있는 라이브러리
		
		// 따라서, 갯수 정하지 않고, 데이터를 마음대로
		// 추가할수도 있고, 삭제할수도 있는것이 어레이 리스트 이다.
		
		// 담고 싶은 데이터를 < > 안에 적어줘야 한다.
		// 비어있는 리스트를 만든다.
		ArrayList<String> nameList = new ArrayList<String>();
		
		nameList.add("홍길동");
		nameList.add("김나나");
		nameList.add("Mike");
		
		System.out.println(nameList.get(2));
		
		// 배열은 > .size() > 저장되어 있는 데이터의 갯수
//		System.out.println(nameList.size());
		for(int i = 0; i < nameList.size(); i++) {
			System.out.println(nameList.get(i));
		}
		
		// 홍길동, 김나나, Mike
		// Harry 를 홍길동과 김나나 사이에 추가!!
		nameList.add(1, "Harry");
		for(int i = 0; i < nameList.size(); i++) {
			System.out.println(nameList.get(i));
		}
		
		System.out.println("-----------------");
		
		nameList.remove(0);
		for(int i = 0; i < nameList.size(); i++) {
			System.out.println(nameList.get(i));
		}
		
		System.out.println("-----------------");
		
		nameList.remove("Mike");
		for(int i = 0; i < nameList.size(); i++) {
			System.out.println(nameList.get(i));
		}
		
		// 저장된 데이터를 전부삭제
		nameList.clear();
		System.out.println(nameList.size());
		
		// 리스트가 비어있는지 확인
		nameList.isEmpty();
		
		if (nameList.isEmpty()) {
			System.out.println("비어있다.");
		} else {
			System.out.println("데이터 있음");
		}
		
		
		
		
	}
	
}
