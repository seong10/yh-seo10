
public class Animal {
	
	private String name;
	
	public void cry() {
		System.out.println(name + "가 소리를 낸다!!");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
