
public class AnimalAction {

			// 여기에서 상속한거임
	// Animal animal = d(new Dog());
	void action(Animal animal) { 
		
		animal.cry();
		
		if (animal instanceof Dog) {
				// instance > 클래스가 heap메모리에 올라온 상태
			((Dog)animal).run();
		} else if (animal instanceof Cat) {
			((Cat)animal).grooming();
		}
		
	}
	
}
