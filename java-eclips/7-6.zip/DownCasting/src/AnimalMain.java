
public class AnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Animal a = new Animal();
//		a.setName("동물");
//		a.cry();
//		
//		System.out.println("-------------");
//		
//		Dog d = new Dog();
//		d.setName("바둑이");
//		d.cry();
//		d.run();
//		
//		System.out.println("-------------");
//		
//		Cat c = new Cat();
//		c.setName("키티");
//		c.cry();
//		c.grooming();
		
		AnimalAction action = new AnimalAction();
		
		Dog d = new Dog();
		d.setName("바둑이");
		// 했으니 Animal 의 setName 함수 써서 name에 바둑이 저장하고
				
		action.action(d);
		// d 는 name이 바둑이로 저장되었으니
		
		Cat c = new Cat();
		c.setName("키티");
		
		action.action(c);
		
	}

}
