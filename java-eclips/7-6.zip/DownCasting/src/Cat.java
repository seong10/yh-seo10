
public class Cat extends Animal {

//	private String name;
	
	// Animal 클래스의 함수 모두 상속받는다.
	
	@Override
	public void cry() {
		// TODO Auto-generated method stub
		super.cry();
		System.out.println("야옹 야옹~~");
	}

	void grooming() {
		System.out.println("그루밍 한다!");
	}
	
	
}
