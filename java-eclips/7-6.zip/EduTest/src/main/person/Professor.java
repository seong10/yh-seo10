package main.person;

public class Professor extends Person {
					// 툴로도 가능
					// > 클래스 만들때 super 을 경로 지정해서

//	protected int num;
//	protected String name;
//	protected String dept;
//	protected String address;

	// Person 의 함수들도 모두 상속 받았다.
	
	private String[] subjects;
	
	public void print() {
		super.print();
		printSubj();
		// this 안써도 자신 클래스 안에있기에 인식 가능
	}
	
	public void printSubj() {
		System.out.println( name + " 교수의 개설 과목");
		for (int i = 0; i < subjects.length ; i++) {
			System.out.println( subjects[i] );
		}
	}

	public String[] getSubjects() {
		return subjects;
	}

	public void setSubjects(String[] subjects) {
		this.subjects = subjects;
	}
	
	public Professor() {
		
	}
	
	public Professor(int num, String name, String dept, String address, String[] subjects) {
//		this.num = num;
//		this.name = name;
//		this.dept = dept;
//		this.address = address;
		// 위에 코드를 super 로 대체 가능
		super(num, name, dept, address);
		
		this.subjects = subjects;
	}

}
