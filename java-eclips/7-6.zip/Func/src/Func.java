
public class Func {

	int add(int a, int b) {
		int result = a + b;
		return result;
	}
//	if(a4 >= 10) {
//	System.out.println("hello");
//} else {
//	System.out.println("bye");
//}
	char getGrade(int size) {
		if(size > 16 && size < 30) {
			return 'A';
		}else if(size > 16 && size < 30) {
			return 'B';
		}else if(size > 16 && size < 30) {
			return 'C';
		}
		return 'X';
		}
		
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Func f = new Func();
		// 컴퓨터에 일시키려면 변수를 만들어야 된다
		int result = f.add(3, 5);
		System.out.println(result);
		
		Func ft = new Func();
		// String result = fu.fruit(20);
		System.out.println(ft.getGrade(20));
		
	}

}
