

public class GrandMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// GrandParent 생성해서 데이터 셋팅한 후 화면 출력 하세요.
		
		GrandParent gp = new GrandParent();
		gp.name = "홍길동";
		gp.age = 20;
		
		gp.print();
		
		System.out.println("-----------------");
		
		// 객체를 생성할때 실행시키지 않았지만 실행되는게 생성자다
		Parent p = new Parent();
		p.name = "김나나";
		p.age = 33;
		p.job = "개발자";
		
		p.print();
		
		System.out.println("-----------------");
		
		Child c = new Child();
			// 차일드 클래스로가서 extends 의 parent 갔다가 다시 extesds의 grandparent
			// grendparent 생성자 호출 해서 parent로가서 jop heap 에 만들고
			// 이어서 child로와 hobby heap에 만들고 // 까지 new child
			// c.name 하니까
			// stack main에 c: 가 생기고 heap을 가르키고
			// print 끝나고 stack 이 사라지는데
			// 그걸 가비지 컬렉터가 지워줌
		c.name = "영수";
		c.age = 22;
		c.job = "마케터";
		c.hobby = "영화";
		
		c.print();
		
		GrandParent gp2 = new GrandParent("홍길동", 32);
		gp2.print();
		
		Parent p2 = new Parent("홍길동", 33, "역도");
		p2.print();
		
		
		Child c2 = new Child("홍길동", 22, "씨름", "운동");
		c2.print();
		
	}

}
