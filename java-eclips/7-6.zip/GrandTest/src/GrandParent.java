
public class GrandParent {

	public String name;
	public int age;
	
	// 오버로딩으로 클래스를 억세스할것을 함수를 억세스
	public GrandParent() {
		System.out.println("GrandParent 생성자 호출됨");	
	}
	
	public GrandParent(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	void print() {
		System.out.println("name : " + name);
		System.out.println("age : " + age);
	}
	
}
