
public class Parent extends GrandParent {

//	String name;
//	int age;
	
	// GrandParent 의 함수들도 상속받았다.
	
	public String job;
	
	public Parent() {
		System.out.println("Parent의  생성자 호출됨");
	}
	
	public Parent(String name, int age, String job){
		super(name, age);
		this.job = job;
	}

	@Override
	void print() {
		// TODO Auto-generated method stub
		super.print();
		System.out.println(job);
	}

	
	
}
