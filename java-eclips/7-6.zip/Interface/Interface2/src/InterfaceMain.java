
public class InterfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyCard card = new MyCard();
		card.cardNumber = "7";
		
		String number = card.getCardNumber();
		System.out.println(number);
		
		card.print();
		
		MyCard card2 = new MyCard("5");
		card2.print();
		
		
		// 상수를 사용할때는 보통 객체.상수로 사용하지 않고,
		System.out.println(card2.CLOVER);
		// 상수를 정의한 인터페이스나 클래스명.상수로 사용한다.
		System.out.println(PlayingCard.CLOVER);
		
	}

}
