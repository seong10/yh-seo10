
public class MyCard implements PlayingCard {
	// 인터페이스는 상속받는게 아니라 PlayingCard를 구현해내는 것이기 때문에 extends가 아닌 implemnts를 적어준다.

	String cardNumber;
	
	public MyCard(String cardNumber){
		this.cardNumber = cardNumber;
	}
	
	public MyCard() {
		
	}

	@Override
	public String getCardNumber() {
		// TODO Auto-generated method stub
		return cardNumber;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Card Number = " + cardNumber);
	}
	

	
	
}
