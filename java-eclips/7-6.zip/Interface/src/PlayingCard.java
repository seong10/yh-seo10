
public interface PlayingCard {

	// 인터페이스는, 추상클래스보다 더 뼈대만 있는 것!
	
	// 인터페이스는, 멤버변수가 없고, 함수의 이름만 있는것
	// 단, 상수는 가능하다
//	String name; //안됨
	// (상수란, 변수인데, 한번 값을 저장하면, 값을 바꿀 수 없는것)
	// ex) flask의 JWT	
	
	// 카드의 클로버는 1, 하트는 2, 다이몬드는 3, 스페이드 4라고
	// 지정한다!!
	public static int CLOVER = 1;
	public static int HEART = 2;
	public static int DIAMOND = 3;
	public static int SPADE = 4;
	
	public String getCardNumber();
	public void print();
}
