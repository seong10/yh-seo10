package main;

import main.book.Member;

public class PhoneBookMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 멤버 클래스 생성하면서, 이름과 전화번호
		// 저장할 수 있도록 만들어 주세요.
		Member m1 = new Member("Mike", "010-1222-2222");
		// 저장한 이름과 전화번호를
		// "Name : Mike , Phone : 010-1222-2222"
		// 출력해주세요.
		m1.print();
		
		// 이름을, Harry 로 변경하려 한다.
		// 멤버변수에 바로 데이터를 저장하는 방법
//		m1.name = "Harry"
		// 하지만 이 방법은 추천하지 않습니다.
		// 왜냐하면, 보안 관점에서!!
		// 따라서, 멤버변수들은 보통은 private 으로 만들어놓는다.
		// 그리고, 함수로 접근을 허용해 준다.
				
		m1.setName("Harry");
		
		m1.print();
		
		m1.setPhone("010-4444-9999");
		
		m1.print();
		
		// 두번째 멤버 데이터를 저장하려고 합니다.
		// 이번에는, 객체를 먼저 생성하고 나서
		// 이름과 전번을 저장하도록 코드를 작성해 주세요.
		Member m2 = new Member();
		m2.setName("Hong");
		m2.setPhone("010-1221-3443");
		
		m2.print();
		
	}

}
