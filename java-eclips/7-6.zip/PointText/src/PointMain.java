
public class PointMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Point p1 = new Point();
		
		p1.x = 1;
		p1.y = 2;
		
		p1.print();
		
		
	}

}
