
public class MaxLimitCalculator extends Calculator {

//	void add(){
//		
//	}
//	
//	int getValue() {
//		if (this.value > 100) {
//			this.value = 100;
//		}
//	return value;
//	}
	
	void add(int val) {
		this.value += val; 
		if (this.value > 100) {
			this.value = 100;
		}
	}
}
