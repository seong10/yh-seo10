
public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		Calculator cal = new Calculator();
//        cal.add(10);
//        System.out.println(cal.getValue());  // 10 출력
		
//        UpgradeCalculator cal = new UpgradeCalculator();
//        cal.add(10);
//        cal.minus(3);
//        System.out.println(cal.getValue());  // 10에서 7을 뺀 3을 출력
        
        MaxLimitCalculator cal = new MaxLimitCalculator();
        cal.add(50);  // 50 더하기
        cal.add(60);  // 60 더하기
        System.out.println(cal.getValue());  // 100 출력
        
	}

}
