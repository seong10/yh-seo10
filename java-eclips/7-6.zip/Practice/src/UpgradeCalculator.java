
public class UpgradeCalculator extends Calculator {

	void minus(int i) {
		this.value -= i;
	}
	
}
