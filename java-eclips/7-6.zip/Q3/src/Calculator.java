
public class Calculator {

    int value;

    Calculator() {
        this.value = 0;
    }

    void add(int val) {
        this.value += val;
    }

    int getValue() {
        return this.value;
    }
    
    boolean isOdd(int num) {
    	if (num % 2 == 1) {
    		return true;
    	} else {
    		return false;
    	}
    }
//		  // 한다음 i++ 로 1씩 추가
//for(int i = 0; i < 6 ; i++) {
//	System.out.println(i);
    int avg(int[] nums) {
    	
    	int sum = 0;
    	
    	for(int i = 0; i < nums.length; i++) {
    		sum = sum + nums[i];
    	}
    	return sum / nums.length;
    }
    	
    
}
