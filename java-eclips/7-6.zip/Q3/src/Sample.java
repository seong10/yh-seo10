
public class Sample {

	public static void main(String[] args) {
	// Q3
	// 클래스의 함수를 하나씩 테스트 하는것을 > 단위테스트!!
//	Calculator cal = new Calculator();
//	
//	System.out.println( cal.isOdd(3) );
	
	// Q4
	int[] data = {1, 15, 5, 7, 9};
	Calculator cal = new Calculator();
	int result = cal.avg(data);
	System.out.println(result);  // 5 출력
	
	}
}
