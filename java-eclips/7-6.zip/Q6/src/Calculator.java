
public class Calculator {
    Integer value;
    // Integer 대문자로 시작하니 클래스
    // value 를 객체로 만든게 없어서 에러가남
    
    // int, float, double 이것을 자바에서는 클래스로도 처리한다
    // > Integer, Float, Double
    
    Calculator(){
//    	value = new interger(0);
    			// 이것도 가능하지만 지금은 에러
    	value = 0;
    }
    
    void add(int val) {
        this.value += val;
    }

    public Integer getValue() {
        return this.value;
    }
}
