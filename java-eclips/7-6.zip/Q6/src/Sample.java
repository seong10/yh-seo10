
public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Calculator cal = new Calculator();
        cal.add(3);  // 여기서 NullPointerException 이 발생한다.
        				// ## 이 에러는 > heap 메모리에 객체생성 안했구나
        System.out.println(cal.getValue());
	}

}
