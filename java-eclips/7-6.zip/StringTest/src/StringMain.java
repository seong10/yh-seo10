
public class StringMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 문자열 생성
		String str1 = "Hello";
		String str2 = new String("Java");
					// 이게 정확한 거지만 편리성으로 위에코드도 실행되게 만들어짐
		String result = str1 + str2;
		System.out.println(str1);
		System.out.println(str2);		
		System.out.println(result);
		
		// 숫자를 문자열로 받을때
		String str3 = "317";
		
		System.out.println( str3 + 10 );

		// 문자열로 되어있는 정수를, 진짜 정수로 바꾸는 방법
		int a = Integer.valueOf(str3).intValue();
		
		System.out.println( a + 10);
		
		String str4 = "5.1234";
		// 문자열로 들어있는 실수를, double 로 바꾸는 방법
		
		double b = Double.valueOf(str4).doubleValue();
		System.out.println( b + 10 );
		
		// 문자열로 들어있는 정수를, 진짜 정수로 바꾸는 방법
		a = Integer.parseInt(str3);
	// 위에서 int로 a를 만들었기에 그냥 'a'가 가능
		System.out.println( a + 20);
		
		float c = Float.parseFloat(str4);
		System.out.println(c + 30);
		
		// 숫자를 문자열로 변환!!! > .valueOf
		int k = 365;
		
		String data = String.valueOf(k);
		System.out.println(data + 10);
		double j = 111.345;
		data = String.valueOf(j);
		System.out.println(data + 10);
		
		// toString 으로 쓸수있지만 String.valueOf 이면
		// int, doulbe 구분없이 쓸수있다
		data = Integer.toString(k);
		data = Double.toString(j);
		
		// 문자열 조작하는 법과 비교하는 법
		String data1 = "abc";
		
		// 문자열의 concat함수
		System.out.println( data1.concat("hello") );
		
		// 문자열의 길이를 구하는 length 함수
		System.out.println( data1.length() );
		
		// 문자열의 일부분을 가져오는 substring 함수
		data1 = "Hello World";
		
		System.out.println( data1.substring(2, 10+1) );
		
		data1 = "red, blue, white";
		// 문자열을 공백으로 분리 하고 싶다. split 함수
 		String[] dataArray = data1.split(", ");
 		for(int i = 0; i < dataArray.length; i++) {
 		System.out.println(dataArray[i]);
 		}
 		
 		data1 = "  abc@naver.com ";
 		System.out.println(data1);
 		
 		// 왼쪽이나 오른쪽에 있는 의미없는 공백을 제거하는 trim() 함수
 		System.out.println(data1.trim());
 		
 		// 대 소 문자 변환해 주는 함수
 		System.out.println( data1.toUpperCase().trim() );
 		System.out.println( data1.toLowerCase().trim() );
 		
 		// 문자열에 어떤 문자가 어디에 있는지 알려주는 indexOf 함수
 		// abc 의 위치를 알려달라.
 		System.out.println( data1.indexOf("abc") );
 		// @ 의 위치는?
 		System.out.println( data1.indexOf("@") );
 		
 		// @를 포함하고 있니??
 		System.out.println( data1.contains("@") ); 
 		System.out.println( data1.contains(".com") );
 		
 		// 문자열 비교 함수 compareTo
 		data1 = "abc";
 		System.out.println( data1.compareTo("abc") );
 		System.out.println( data1.compareTo("aba") );
 		System.out.println( data1.compareTo("bba") );
 		System.out.println( data1.compareTo("abd") );

 		// 실무에서 사용은 이렇게
 		if (data1.compareTo("aba") < 0) {
 			System.out.println("작다");
 		}else if (data1.compareTo("aba") > 0) {
 			System.out.println("크다");
 		}else {
 			System.out.println("같다");
 		}
 		
 		// 문자열이 같은지 체크하는 함수 equals
 		
 		System.out.println(data1.equals("abc"));
 		System.out.println(data1.equals("ABC"));
 		
	}

}
