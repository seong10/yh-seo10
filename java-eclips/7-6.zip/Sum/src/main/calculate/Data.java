package main.calculate;

public class Data {

	public int add(int x, int y) {
		return x + y;
	}

	public double add(double x, double y) {
		// TODO Auto-generated method stub
		return x + y;
	}

	public String add(String x, String y) {
		// TODO Auto-generated method stub
		return x + y;
	}
		
}
