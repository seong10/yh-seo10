package main.calculate;

public class Data2 {

//	public Data2(int x, int y) {
//		int result = x + y;
//	}
		// 이렇게하면 stack 메모리에
		// 'int result' 함수만 저장되서 함수가 끝나면 사라지는것
	
	// 따라서 이렇게 만들어야됨
	public int resultInt;
	public double resultDouble;
	public String resultString;
	
	public Data2(int x, int y) {
		resultInt = x + y;
	}

	public Data2(double x, double y) {
		resultDouble = x + y;
	}

	public Data2(String x, String y) {
		resultString = x + y;
	}

	public void printInt() {
		System.out.println(resultInt);
	}
	
	public void printDouble() {
		System.out.println(resultDouble);
	}
	
	public void printString() {
		System.out.println(resultString);
	}
	
}
