import java.util.ArrayList;

public class TryMain {

	// try catch finally 문법 : 예외를 처리하는 방법
	// 예외가 발생했을때, 내가 원하는 코드를 실행시키는 방법
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {15, 2, 7};
		
		try {
		
			for(int i = 0; i < 3; i++) {
				System.out.println(arr[i]);
			}
			
			ArrayList<String> myList = null;
			// 키워드가 있으면 = 오른쪽에 new 라던가로 객체를 만들어 줘야함
			
			myList.add("안녕?");
			
			int k = 4 / 0;
			
			System.out.println(k);
		// 에러가 발생하면 catch 하고 아니면 그대로 실행
		} 
//			catch (Exception e) {
//			System.out.println("예외 발생!!" + e.toString());
//		}
			catch ( ArrayIndexOutOfBoundsException e) {
				System.out.println("배열 인덱스 예외 발생시 처리코드");
				System.out.println(e.toString()); // getMessage() > 에러의 마지막 메세지만
			} catch (ArithmeticException e) {
				System.out.println("연산 예외 발생시 처리하는 코드");
				System.out.println(e.toString());
			} catch (Exception e) {
				System.out.println("나머지 모든 예외상황은 여기서 처리");
				System.out.println(e.toString());
				// NullPointerException > heap에 객체생성 안됬는데, 즉 메모리에 없는데 넣을수없다
			} finally {
				System.out.println("예외 발생하든 발생하지 않든, 꼭 실행해야 하는 코드는 여기 작성");
			}
		// 필요에 의해서 문법을 배워야지 적용할수있음 / 문법을 배우고서 적용하려면은 못함
	}

}
