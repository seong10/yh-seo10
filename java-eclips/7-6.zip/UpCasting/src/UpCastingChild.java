
public class UpCastingChild extends UpCastingParent {

//	int x;
//	int y;
	
	// UpCatingParent 의 함수들도 상속 받았다.
	
	int z;
	
	public UpCastingChild() {
		x = 100;
		y = 200;
		z = 300;
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
//		super.print(); // 재활용 못함
		System.out.println(x + " , " + y + " , " + z);
	}

	@Override
	public int add() {
		// TODO Auto-generated method stub
		System.out.println("Child 의 add() 함수 호출");
		return x + y + z;
	}
	
	public int sub() {
		return x - y - z;
	}

	public int getZ() {
		return z;
	}

	public void setZ(int z) {
		this.z = z;
	}
	
	
	
}
