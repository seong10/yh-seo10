
public class UpCastingParent {

	int x;
	int y;
	
	public UpCastingParent(){
		x = 10;
		y = 20;			
	}
	
	public void print() {
		System.out.println( x + " , " + y );
	}
	
	public int add() {
		System.out.println("Parent 의 add() 함수 호출.");
		return x + y;
	}
	
}
