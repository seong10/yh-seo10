

public class ArrayTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
//		// 데이터를 여러개 저장하는, 가장 기본적인 방법
//		// 배열 (Array)
//		
//		int [] arr = new int[5] ;
//		
//		arr[0] = 1;
//		arr[1] = 2;
//		arr[2] = 3;
//		arr[3] = 4;
//		arr[4] = 5;
//		System.out.println( arr[1] );
//
//		int[] arr2 = {1,2,3,4,5};
//		
//		System.out.println( arr2[3] );
//		
//		// arr2에 있는 모든 데이터를 출력하세요
//		for(int i = 0; i <= 5 ; i++) {
//			System.out.println(arr2[i]);
//		}
//		
//		int j = 0;
//		while( j <= 4) {
//			System.out.println(arr2[j]);
//			j = j + 1;
//		}
//		
//		// 인덱스의 길이를 찾을수있다
//		System.out.println();
//		System.out.println(arr2.length);
//		System.out.println();
//		
//		for(int i = 0; i < arr2.length ; i++) {
//			System.out.println(arr2[i]);
//		
//		}
		
		// 학생들 20명의 점수를 관리하려 합니다.
		// 반복문 사용해서 학생 데이터를 전부 30으로 만들어 주세요.
		int [] socre = new int[20] ;
		for(int i = 0; i < socre.length; i++) {
			socre[i] = 30;
			System.out.println(socre[i]);
		}
		
		
		
	}

}
