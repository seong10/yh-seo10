// public 안써도 괜찮음
public class Hi{
		// 클래스name
		// java 는 들여쓰기를 {}(중괄호) 로함
	public static void main(String[] args) {
//		System.out.println("안녕하세요");
//	  // system 의 라이브러리의 out 의 println 으로 하는것
//						// 문자열 > ""(큰따옴표로), 그리고 ; 세미콜론
//
//		// TODO Auto-generated method stub
//
//		String data = "떡볶이";
//	// 문자열 변수하려면 String		
//			// 변수는 소문자로시작
//			
//		int count = 2;
//		
//		String lang = "JAVA";
//		
//		float data2 = 5.22f;
//	// 즉 저장하려는 변수가 뭔지 알려줘야됨
//					// f > 소숫점이 붙어있는것이다
//		System.out.println(count);
//		System.out.println(lang);
//				// print 그냥쓰면 옆으로 붙어나옴
//				// 즉 ln 붙이면 라인바꿔서 나옴
//		
//		// 미리 변수를 만들고 나중에 저장할 수도 있음
//		int a = 10;
//		int b;
//				
//		b = a + 5;
//		
//		System.out.println(b);
//		
//		// 자바에선 true가 소문자
//		boolean p = true;
//		byte c = 10;
//		short d = 20;
//		int e = 300;
//		long f = 100;
//		
//		// double 은 f 안붙임
//		float g = 12.5f;
//		double h = 34.9;
//		
//		// 문자 하나일때는 ''(작은따옴표)
//		char i = 'a';
//		String j = "abc";
//	
//		// 옆으로 써도되지만 가독성위해 아래로
//		int a2 = 12;
//		int b2 = 13;
//		
//		// a와 b를 더해서, 2로 나눌것이다.
//		float c2 = (a2 + b2) / 2;
//		System.out.println(c2);
//		
//		// 함수 계속 써도됨
//		// float 다시 안써도됨
//		c2 = a2 + b2 ;
//		System.out.println(c2);
//		
//		c2 = a2 * b2 ;
//		System.out.println(c2);
//		
//		c2 = a2 / b2 ;
//		System.out.println(c2);
//		
//		c2 = a2 % b2 ;
//		System.out.println(c2);
//		
//		
//		int d2 = 5;
//		// d++ 란 뜻은, 원래 있던 d값에 +1 하라는뜻
//		// 근데 메모리에 저장!! d = d + 1;
//		System.out.println(d2++);
//			// 근데 왜 값이 안바뀌나? 프린트를 먼저찍고서 변수처리
//		System.out.println(d2);
//		
//		// ++d 잎에 + 쓰면 먼저 메모리에 정하고 프린트 실행
//		System.out.println(++d2);
//		System.out.println(++d2);
//		
//		System.out.println(d2--);
//		System.out.println(d2);
//		System.out.println(--d2);
//		
//		// 부등호
//		System.out.println(a == b);
//		System.out.println(a != b);
//		System.out.println(a > b);
//		System.out.println(a < b);
//		System.out.println(a >= b);
//		System.out.println(a <= b);
//		
//		// a는 10과 같고, b는 20과 같은지?
//		// 자바에서는 and > &&
//		System.out.println(a == 10 && b == 20);
//		
//		// a가 10 이거나 b가 20인지??
//		// 자바에서는 하거나, 또는 (or) > ||
//		System.out.println(a == 10 || b == 20);
//		System.out.println(a > 10 && b <= 20);
//		
//		/* 저는
//		코멘트를
//		여기까지 하고싶습니다. */
//		
//		// 조건문
//		int a4 = 10;
//		int b4 = 20;
//		
//		// a가 10보다 크거나 같으면, hello 출력하고
//		// a가 10보다 작으면, bye 를 출력
//		
//		// 괄호로 쓰고,콜론 안쓰고, 중괄호 쓰고
//		if(a4 >= 10) {
//			System.out.println("hello");
//		} else {
//			System.out.println("bye");
//		}
//		
//		// a 가 30보다 크면, hello
//		// a 가 20보다 크면, hi
//		// a 가 30보다 크면, good
//		// 그렇지 않으면 bye
//		if (a4 > 30) {
//			System.out.println("hello");
//		} else if(a4 > 20) {
//			System.out.println("hi");			
//		} else if(a4 > 10) {
//			System.out.println("good");	
//		} else {
//			System.out.println("bye");	
//		}
//		
//		int a = 7;
//		
//		//switch case 문법
//		// 오류를 발생할 확률이 커서 잘안씀 차라리 if문 > break; 를 다써줘야해서
//		switch(a) {
//		case 1 : //case를 숫자변수로 하면 숫자로
//			System.out.println("1");
//			break; // 꼭 브레이크가 써져야됨
//		case 3 :
//			System.out.println("3");
//			break;
//		case 7 :
//			System.out.println("7");
//			break;
//		case 9 :
//			System.out.println("9");
//			break;
//		default : 
//			System.out.println("1000");
//			break;
//		}
//		
//		// 반복문 for, while
//		
//		int a = 0;
//		// 0, 1, 2, 3, 4, 5 화면에 출력
//		
//		System.out.println(a);
//		a = a + 1;
//		
//		System.out.println(a);
//		a = a + 1;
//		System.out.println(a);
//		a = a + 1;
//		System.out.println(a);
//		a = a + 1;
//		System.out.println(a);
//		a = a + 1;
//		System.out.println(a);
//		a = a + 1;
//		
//		// int i = 0; > 변수를 초기화 해주는문장
//				  // i < 6 ; 맞으면 프린터로가서 출력
//				  // 한다음 i++ 로 1씩 추가
//		for(int i = 0; i < 6 ; i++) {
//			System.out.println(i);
//		}
//		
//		
//		// 1부터 100까지 숫자를 다 더한값을 출력해주세요.
//		int sum = 0;
//		for(int i = 0; i <= 100; i++) {
//			sum = sum + i;
//		}
//		System.out.println(sum);
//		
//		// 1부터 100까지 홀수만 다 더한값을 출력해주세요.
//		int sum = 0;
//		for(int i = 0; i <= 100; i++) {
//			if(i % 2 == 1) {
//				sum = sum + i;
//			}
//		}
//		System.out.println(sum);
//		
//		/* 2 X 1 = 2
//		 * 2 X 2 = 4
//		 * 2 X 3 = 6
//		 * .
//		 * .
//		 * 9 X 9 = 81
//		 */
//		// 구구단
//		for(int i = 2; i <= 9; i++) {
//			for(int j = 1; j <= 9; j++) {
//				int result = i * j;
//				System.out.println(i + "X" +j+ "="+ result);
//			}
//		}
//		
//		// 반복문 while
//		int i = 0;
//		while( i < 6 ) {
//			System.out.println(i);
//			i = i + 1;
//		}
//		
//		// 1부터 100까지 while문으로 더한값을 출력
//		int i = 1;
//		int sum = 0;
//		while( i <= 100 ) {
//			System.out.println(i);
//			sum = sum + i;
//			i = i + 1;
//		}
//		System.out.println(sum);
		
		// 1부터 100까지 while문 이용해서 다 더하되,
		// 더한값이 1000보다 크면, 그만 더하고 멈춘다.
		// 그리고 그때의 합한 값을 출력
		int i = 1;
		int sum = 0;
		while( i <= 100 ) {
			System.out.println(i);
			sum = sum + i;
			if(sum > 1000) {
				break;
			}
			i = i + 1;
		}
		System.out.println(sum);
		
		
	}	
}